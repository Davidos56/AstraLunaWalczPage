function [y] = a2(x, c)
    y = x.*x.*x.*x -4.*(x.*x.*x)*c +6.*(x.*x).*c.^2 -4.*x.*c.^3 + c.^4;
end

