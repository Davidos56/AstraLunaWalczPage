% zad 2
disp("Zad 2");

clc
clear
close all

format long e

% double prec
k=4:10;
x=10.^k;

w1d = (x - sqrt(1 + x.^2))'
w2d = (-1./(x + sqrt(1+x.^2)))'

% single prec
ks=single(4:10);
xs=single(10.^k);

w1s = single(single(xs) - single(sqrt(1 + single(xs).^2)))'
w2s = single(-1./(single(xs) + single(sqrt(1+single(xs).^2))))'
