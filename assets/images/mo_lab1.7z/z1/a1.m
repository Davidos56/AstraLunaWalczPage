function [y] = a1(x)
    y = (x-2).^4;
end
