% zad 3
disp("Zad 3");

close all
clear

d = 10^(-3);
x = linspace( 2-d, 2+d, 1000 );

hold on
plot(x(:), a1(x), 'r');
plot(x(:), a2(x, 2), 'g');

h = d/500;
k = 1:1000;
xk = 2 - d + k.*h;
err = abs(a1(xk) - a2(xk, 2));
maxk = max(err);


figure();
plot(x(:), err(:), 'b');
