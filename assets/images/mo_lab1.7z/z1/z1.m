% zad 1
disp("Zad 1");

clc
clear
format long e

x = 29/13
x1 = 29 / 1300
y = 29 - 13 * x
y1 = 29 - 1300 * x1

